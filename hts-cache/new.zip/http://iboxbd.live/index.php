<!DOCTYPE html>
<html lang="en">
 <head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />

    <title>iBoxBD LIVE</title>

    <link
      href="https://fonts.googleapis.com/css?family=Lato:100,300,400,700,900&amp;subset=latin-ext" rel="stylesheet"/>

    <link rel="stylesheet" href="assets/css/bootstrap.min.css" />
    <!--FontAwesome nin css -->
    <link rel="stylesheet" href="assets/css/font-awesome.min.css" />
    <!--Owl carousel css-->
    <link rel="stylesheet" href="assets/css/owl.carousel.css" />
    <!-- <link rel="stylesheet" href="flowplayer/skin/skin.css"> -->
    <!--Style css-->
    <link rel="stylesheet" href="assets/style.css" />
	<link rel="stylesheet" media="screen" href="assets/css/noyan.css">

    <!--jquery-1.12.0.min.js-->
    <script src="assets/js/vendor/jquery-1.12.0.min.js"></script>
    <!-- <script src="flowplayer/flowplayer.min.js"></script> -->

    <!--[if lt IE 9]>
      <script src="//oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="//oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
  </head>

  <body class="demo2" oncontextmenu="return false" onselectstart="return false" ondragstart="return false">
    <header>
      <div class="container text-center">
        <div class="logo-mid">
          <a href="index.php"> <img src="logo.png" class="img-responsive" /></a>
        </div>
      </div>
    </header>

    <iframe name="tv" class="ifream" src="player.php?stream=1" allowfullscreen></iframe>
	
	
	<!--marquee><p><b><span>।।  বিজ্ঞপ্তি  ।।</span> <font color="yellow"> সম্মানিত গ্রাহক,BDCINEPLEX LIVE এ আপনাদের স্বাগতম ।। সকলের প্রিয় BDCINEPLEX এখন আরো নতুন নতুন চ্যানেল নিয়ে এখন আপনার হাতের মুঠোয় । </font></b></p></marquee-->

    <!-- <div class="player">
    <div class="flowplayer">
      <video>
         <source type="video/webm" src="https://edge.flowplayer.org/bauhaus.webm">
         <source type="video/mp4" src="https://edge.flowplayer.org/bauhaus.mp4">
      </video>
   </div>
  </div> -->
    <!--Header End-->
    <div class="owl-filter">
      <div class="container-fluid custom_fluid">
        <div class="row">
          <div class="col-md-12">
            <div class="filter-menu">
              <ul>
                <li class="filter-btn btn-active" data-filter="*">
                  All Channel
                </li>
                <li class="filter-btn" data-filter=".bangla">Bangla</li>
                <li class="filter-btn" data-filter=".inbangla">Indian Bangla</li>
                <li class="filter-btn" data-filter=".hindi">Indian</li>
                <li class="filter-btn" data-filter=".sports">Sports</li>
                <li class="filter-btn" data-filter=".kids">Cartoon</li>
                <li class="filter-btn" data-filter=".documentary">Documentary</li>
                <li class="filter-btn" data-filter=".english">English</li>
                <li class="filter-btn" data-filter=".music">Music</li>
              </ul>
            </div>
            <div class="filter-item">
              <!-- ====== Bangla Channels ====  -->
              <!--div class="item bangla">
                <div class="item_content">
                  <a herf="#" onclick="tv.location.href='player.php?stream=1'" >
                    <img src="assets/images/gtvhd.png" class="img-responsive"/></a>
                </div>
              </div-->
              <div class="item bangla">
                <div class="item_content">
                  <a herf="#" onclick="tv.location.href='player.php?stream=1'">
                    <img src="assets/images/gtv.png" class="img-responsive"/></a>
                </div>
              </div>
			  
              <div class="item bangla">
                <div class="item_content">
                  <a herf="#" onclick="tv.location.href='player.php?stream=13'">
                    <img src="assets/images/jamunatv.png" class="img-responsive"/></a>
                </div>
              </div>
              <div class="item bangla">
                <div class="item_content">
                  <a herf="#" onclick="tv.location.href='player.php?stream=17'">
                    <img src="assets/images/somoytv.jpg" class="img-responsive"/></a>
                </div>
              </div>
             <div class="item bangla">
                <div class="item_content">
                  <a herf="#" onclick="tv.location.href='player.php?stream=6'">
                    <img src="assets/images/channeli.jpg" class="img-responsive"/></a>
                </div>
              </div>
             
              <div class="item bangla">
                <div class="item_content">
                  <a herf="#" onclick="tv.location.href='player.php?stream=18'">
                    <img src="assets/images/news24.png" class="img-responsive" /></a>
                </div>
              </div>
              <div class="item bangla">
                <div class="item_content">
                  <a
                    herf="#"
                    onclick="tv.location.href='player.php?stream=51'"
                    ><img src="assets/images/maasranga.png" class="img-responsive"
                  /></a>
                </div>
              </div>
              <div class="item bangla">
                <div class="item_content">
                  <a
                    herf="#"
                    onclick="tv.location.href='player.php?stream=65'"
                    ><img src="assets/images/etv.jpg" class="img-responsive"
                  /></a>
                </div>
              </div>
              <div class="item bangla">
                <div class="item_content">
                  <a
                    herf="#"
                    onclick="tv.location.href='player.php?stream=5'"
                    ><img src="assets/images/channel24.png" class="img-responsive"
                  /></a>
                </div>
              </div>
             <div class="item bangla">
                <div class="item_content">
                  <a
                    herf="#"
                    onclick="tv.location.href='player.php?stream=12'"
                    ><img src="assets/images/independent.png" class="img-responsive"
                  /></a>
                </div>
              </div>
              <div class="item bangla">
                <div class="item_content">
                  <a
                    herf="#"
                    onclick="tv.location.href='player.php?stream=53'"
                    ><img src="assets/images/BTV.png" class="img-responsive"
                  /></a>
                </div>
              </div>
              <div class="item bangla">
                <div class="item_content">
                  <a
                    herf="#"
                    onclick="tv.location.href='player.php?stream=14'"
                    ><img src="assets/images/rtv.png" class="img-responsive"
                  /></a>
                </div>
              </div>
              <div class="item bangla">
                <div class="item_content">
                  <a
                    herf="#"
                    onclick="tv.location.href='player.php?stream=54'"
                    ><img src="assets/images/ntv.jpg" class="img-responsive"
                  /></a>
                </div>
              </div>
              <div class="item bangla">
                <div class="item_content">
                  <a
                    herf="#"
                    onclick="tv.location.href='player.php?stream=3'"
                    ><img src="assets/images/banglavision.png" class="img-responsive"
                  /></a>
                </div>
              </div>
              <div class="item bangla">
                <div class="item_content">
                  <a
                    herf="#"
                    onclick="tv.location.href='player.php?stream=2'"
                    ><img src="assets/images/atnbangla.jpg" class="img-responsive"
                  /></a>
                </div>
              </div>
              <div class="item bangla">
                <div class="item_content">
                  <a
                    herf="#"
                    onclick="tv.location.href='player.php?stream=4'"
                    ><img src="assets/images/channel9.png" class="img-responsive"
                  /></a>
                </div>
              </div>
              <div class="item bangla">
                <div class="item_content">
                  <a herf="#" onclick="tv.location.href='player.php?stream=7'">
                    <img src="assets/images/dbcnews.png" class="img-responsive"/></a>
                </div>
              </div>
              <div class="item bangla">
                <div class="item_content">
                  <a
                    herf="#"
                    onclick="tv.location.href='player.php?stream=56'"
                    ><img src="assets/images/mytv.png" class="img-responsive"
                  /></a>
                </div>
              </div>
              <div class="item bangla">
                <div class="item_content">
                  <a
                    herf="#"
                    onclick="tv.location.href='player.php?stream=8'"
                    ><img src="assets/images/deeptotv.jpg" class="img-responsive"
                  /></a>
                </div>
              </div>
              <!--div class="item bangla">
                <div class="item_content">
                  <a herf="#" onclick="tv.location.href='player.php?stream=bijoytv.html'" >
                    <img src="assets/images/bijoytv.png" class="img-responsive"/></a>
                </div>
              </div-->
              <div class="item bangla">
                <div class="item_content">
                  <a herf="#"onclick="tv.location.href='player.php?stream=15'" >
                    <img src="assets/images/satv.png" class="img-responsive"/></a>
                </div>
              </div>
              <div class="item bangla">
                <div class="item_content">
                  <a herf="#" onclick="tv.location.href='player.php?stream=11'">
                    <img src="assets/images/ekattor.jpg" class="img-responsive"/></a>
                </div>
              </div>
              <div class="item bangla">
                <div class="item_content">
                  <a herf="#" onclick="tv.location.href='player.php?stream=62'">
                    <img src="assets/images/asiantv.jpg" class="img-responsive"/></a>
                </div>
              </div>
              <div class="item bangla">
                <div class="item_content">
                  <a herf="#" onclick="tv.location.href='player.php?stream=61'">
                    <img src="assets/images/boishakhitv.jpg" class="img-responsive"/></a>
                </div>
              </div>
              <div class="item bangla">
                <div class="item_content">
                  <a herf="#" onclick="tv.location.href='player.php?stream=59'">
                    <img src="assets/images/nagorik.png" class="img-responsive"/></a>
                </div>
              </div>
              <div class="item bangla">
                <div class="item_content">
                  <a herf="#" onclick="tv.location.href='player.php?stream=50'">
                    <img src="assets/images/mohonatv.jpg" class="img-responsive"/></a>
                </div>
              </div>
              <div class="item bangla">
                <div class="item_content">
                  <a herf="#" onclick="tv.location.href='player.php?stream=19'">
                    <img src="assets/images/banglatv.png" class="img-responsive"/></a>
                </div>
              </div>
              <!--div class="item bangla">
                <div class="item_content">
                  <a herf="#" onclick="tv.location.href='player.php?stream=peacebangla.html'">
                    <img src="assets/images/peacebangla.png" class="img-responsive"/></a>
                </div>
              </div-->
              
			  <div class="item bangla">
                <div class="item_content">
                  <a herf="#" onclick="tv.location.href='player.php?stream=16'">
                    <img src="assets/images/85.jpg" class="img-responsive"/></a>
                </div>
              </div>
			  
			  <div class="item bangla">
                <div class="item_content">
                  <a herf="#" onclick="tv.location.href='player.php?stream=63'">
                    <img src="assets/images/94.jpg" class="img-responsive"/></a>
                </div>
              </div>
			  
			  <div class="item bangla">
                <div class="item_content">
                  <a herf="#" onclick="tv.location.href='player.php?stream=49'">
                    <img src="assets/images/108.jpg" class="img-responsive"/></a>
                </div>
              </div>
			  
			  <div class="item bangla">
                <div class="item_content">
                  <a herf="#" onclick="tv.location.href='player.php?stream=19'">
                    <img src="assets/images/106.jpg" class="img-responsive"/></a>
                </div>
              </div>
			  
			  <div class="item bangla">
                <div class="item_content">
                  <a herf="#" onclick="tv.location.href='player.php?stream=9'">
                    <img src="assets/images/98.jpg" class="img-responsive"/></a>
                </div>
              </div>
			  
			  
               <!-- ======= Indian Bangla Channels ======== -->

              <div class="item inbangla">
                <div class="item_content">
                  <a
                    herf="#"
                    onclick="tv.location.href='player.php?stream=66'"
                    ><img src="assets/images/colorsbangla.png" class="img-responsive"
                  /></a>
                </div>
              </div>
              <div class="item inbangla">
                <div class="item_content">
                  <a
                    herf="#"
                    onclick="tv.location.href='player.php?stream=33'"
                    ><img src="assets/images/sonyaath.png" class="img-responsive"
                  /></a>
                </div>
              </div>

              <div class="item inbangla">
                <div class="item_content">
                  <a
                    herf="#"
                    onclick="tv.location.href='player.php?stream=34'"
                    ><img src="assets/images/zeebangla.png" class="img-responsive"
                  /></a>
                </div>
              </div>

              <div class="item inbangla">
                <div class="item_content">
                  <a
                    herf="#"
                    onclick="tv.location.href='player.php?stream=29'"
                    ><img src="assets/images/zeebanglacinema.png" class="img-responsive"
                  /></a>
                </div>
              </div>
             
              <div class="item inbangla">
                <div class="item_content">
                  <a
                    herf="#"
                    onclick="tv.location.href='player.php?stream=30'"
                    ><img
                      src="assets/images/starjalsha.png"
                      class="img-responsive"
                  /></a>
                </div>
              </div>
              <div class="item inbangla">
                <div class="item_content">
                  <a
                    herf="#"
                    onclick="tv.location.href='player.php?stream=31'"
                    ><img
                      src="assets/images/jalshamovies.png"
                      class="img-responsive"
                  /></a>
                </div>
              </div>
			  
			  <div class="item inbangla">
                <div class="item_content" >
                  <a
                    herf="#"
                    onclick="tv.location.href='player.php?stream=32'"
                    ><img
                      src="assets/images/109.jpg"
                      class="img-responsive"
                  /></a>
                </div>
              </div>
			  
			  <div class="item inbangla">
                <div class="item_content" >
                  <a
                    herf="#"
                    onclick="tv.location.href='player.php?stream=29'"
                    ><img
                      src="assets/images/72.jpg"
                      class="img-responsive"
                  /></a>
                </div>
              </div>
              <!-- ======== English Channels ========= -->

            <div class="item english">
                <div class="item_content">
                  <a herf="#" onclick="tv.location.href='player.php?stream=42'">
                    <img src="assets/images/hbo.png" class="img-responsive"/></a>
                </div>
              </div>
          <div class="item english">
                <div class="item_content">
                  <a herf="#" onclick="tv.location.href='player.php?stream=78'">
                    <img src="assets/images/anBDCINEPLEX.png" class="img-responsive"
                  /></a>
                </div>
              </div>
              <!--div class="item english">
                <div class="item_content">
                  <a herf="#" onclick="tv.location.href='player.php?stream=foxlife.html'">
                    <img src="assets/images/foxlife.png" class="img-responsive"
                  /></a>
                </div>
              </div>
              <div class="item english">
                <div class="item_content">
                  <a herf="#" onclick="tv.location.href='player.php?stream=axn.html'">
                    <img src="assets/images/axn.png" class="img-responsive"
                  /></a>
                </div>
              </div>
              <div class="item english">
                <div class="item_content">
                  <a herf="#" onclick="tv.location.href='player.php?stream=starworld.html'">
                    <img src="assets/images/starworld.png" class="img-responsive"
                  /></a>
                </div>
              </div>
              <div class="item english">
                <div class="item_content">
                  <a herf="#" onclick="tv.location.href='player.php?stream=starmovies.html'">
                    <img src="assets/images/starmovies.png" class="img-responsive"
                  /></a>
                </div>
              </div>
              <div class="item english">
                <div class="item_content">
                  <a herf="#" onclick="tv.location.href='player.php?stream=starmoviesselect.html'">
                    <img src="assets/images/starmoviesselect.png" class="img-responsive"
                  /></a>
                </div>
              </div-->

              <div class="item english">
                <div class="item_content">
                  <a herf="#" onclick="tv.location.href='player.php?stream=41'">
                    <img src="assets/images/sonypix.png" class="img-responsive"
                  /></a>
                </div>
              </div>
              <div class="item english">
                <div class="item_content">
                  <a herf="#" onclick="tv.location.href='player.php?stream=44'">
                    <img src="assets/images/bbcworldnews.png" class="img-responsive"
                  /></a>
                </div>
              </div>
              <!--div class="item english">
                <div class="item_content">
                  <a herf="#" onclick="tv.location.href='player.php?stream=lotusmacau.html'">
                    <img src="assets/images/lotusmacau.png" class="img-responsive"
                  /></a>
                </div>
              </div-->
              <div class="item english">
                <div class="item_content">
                  <a herf="#" onclick="tv.location.href='player.php?stream=39'">
                    <img src="assets/images/mnx.png" class="img-responsive"
                  /></a>
                </div>
              </div>
              
              <div class="item english">
                <div class="item_content">
                  <a herf="#" onclick="tv.location.href='player.php?stream=45'">
                    <img src="assets/images/moviesnow.png" class="img-responsive"
                  /></a>
                </div>
              </div>
              <!--div class="item english">
                <div class="item_content">
                  <a herf="#" onclick="tv.location.href='player.php?stream=romedynow.html'">
                    <img src="assets/images/romedynow.jpg" class="img-responsive"
                  /></a>
                </div>
              </div>
              <div class="item english">
                <div class="item_content">
                  <a herf="#" onclick="tv.location.href='player.php?stream=fyi.html'">
                    <img src="assets/images/fyi.png" class="img-responsive"
                  /></a>
                </div>
              </div>
              <div class="item english">
                <div class="item_content">
                  <a herf="#" onclick="tv.location.href='player.php?stream=ytn.html'">
                    <img src="assets/images/ytn.png" class="img-responsive"
                  /></a>
                </div>
              </div>
              <div class="item english">
                <div class="item_content">
                  <a herf="#" onclick="tv.location.href='player.php?stream=nhk.html'">
                    <img src="assets/images/nhk.png" class="img-responsive"
                  /></a>
                </div>
              </div-->
			  
			  
			  <div class="item english">
                <div class="item_content">
                  <a herf="#" onclick="tv.location.href='player.php?stream=47'">
                    <img src="assets/images/18.jpg" class="img-responsive"
                  /></a>
                </div>
              </div>
			  
			  <div class="item english">
                <div class="item_content">
                  <a herf="#" onclick="tv.location.href='player.php?stream=69'">
                    <img src="assets/images/05.jpg" class="img-responsive"
                  /></a>
                </div>
              </div>

              <!-- ======= Hindi Channels ======== -->
            <!--div class="item hindi">
                <div class="item_content">
                  <a
                    herf="#"
                    onclick="tv.location.href='player.php?stream=2.html'"
                    ><img
                      src="assets/images/utvaction.png"
                      class="img-responsive"
                  /></a>
                </div>
              </div-->

              <div class="item hindi">
                <div class="item_content">
                  <a
                    herf="#"
                    onclick="tv.location.href='player.php?stream=75'"
                    ><img
                      src="assets/images/stargoldhd.png"
                      class="img-responsive"
                  /></a>
                </div>
              </div>
              <!--div class="item hindi">
                <div class="item_content">
                  <a
                    herf="#"
                    onclick="tv.location.href='player.php?stream=stargold2.html'"
                    ><img
                      src="assets/images/stargold2.png"
                      class="img-responsive"
                  /></a>
                </div>
              </div-->
              <div class="item hindi">
                <div class="item_content">
                  <a
                    herf="#"
                    onclick="tv.location.href='player.php?stream=67'"
                    ><img
                      src="assets/images/starplus.png"
                      class="img-responsive"
                  /></a>
                </div>
              </div>
             <div class="item hindi">
                <div class="item_content">
                  <a
                    herf="#"
                    onclick="tv.location.href='player.php?stream=68'"
                    ><img
                      src="assets/images/colors.png"
                      class="img-responsive"
                  /></a>
                </div>
              </div>
              <div class="item hindi">
                <div class="item_content">
                  <a
                    herf="#"
                    onclick="tv.location.href='player.php?stream=38'"
                    ><img
                      src="assets/images/sony.png"
                      class="img-responsive"
                  /></a>
                </div>
              </div>
              <div class="item hindi">
                <div class="item_content">
                  <a
                    herf="#"
                    onclick="tv.location.href='player.php?stream=77'"
                    ><img
                      src="assets/images/sonymax.png"
                      class="img-responsive"
                  /></a>
                </div>
              </div>
              <div class="item hindi">
                <div class="item_content">
                  <a
                    herf="#"
                    onclick="tv.location.href='player.php?stream=36'"
                    ><img
                      src="assets/images/sonysab.png"
                      class="img-responsive"
                  /></a>
                </div>
              </div>
              <div class="item hindi">
                <div class="item_content">
                  <a
                    herf="#"
                    onclick="tv.location.href='player.php?stream=40'"
                    ><img
                      src="assets/images/zeetv.png"
                      class="img-responsive"
                  /></a>
                </div>
              </div>
              <div class="item hindi">
                <div class="item_content">
                  <a
                    herf="#"
                    onclick="tv.location.href='player.php?stream=76'"
                    ><img
                      src="assets/images/zeecinema.png"
                      class="img-responsive"
                  /></a>
                </div>
              </div>
              <!--div class="item hindi">
                <div class="item_content">
                  <a
                    herf="#"
                    onclick="tv.location.href='player.php?stream=zeeclassic.html'"
                    ><img
                      src="assets/images/zeeclassic.png"
                      class="img-responsive"
                  /></a>
                </div>
              </div>
              <div class="item hindi">
                <div class="item_content">
                  <a
                    herf="#"
                    onclick="tv.location.href='player.php?stream=zeeaction.html'"
                    ><img
                      src="assets/images/zeeaction.png"
                      class="img-responsive"
                  /></a>
                </div>
              </div>
              <div class="item hindi">
                <div class="item_content">
                  <a herf="#"  onclick="tv.location.href='player.php?stream=hummasala.html'">
                    <img src="assets/images/hummasala.png" class="img-responsive"/></a>
                </div>
              </div-->
              <div class="item hindi">
                <div class="item_content">
                  <a herf="#"  onclick="tv.location.href='player.php?stream=74'">
                    <img src="assets/images/andtv.png" class="img-responsive"/></a>
                </div>
              </div>
              <div class="item hindi">
                <div class="item_content">
                  <a herf="#"  onclick="tv.location.href='player.php?stream=100'">
                    <img src="assets/images/andpic.png" class="img-responsive"/></a>
                </div>
              </div>
              <!--div class="item hindi">
                <div class="item_content">
                  <a herf="#"  onclick="tv.location.href='player.php?stream=bharat.html'">
                    <img src="assets/images/bharat.png" class="img-responsive"/></a>
                </div>
              </div>
              <div class="item hindi">
                <div class="item_content">
                  <a herf="#"  onclick="tv.location.href='player.php?stream=manoranjan.html'">
                    <img src="assets/images/manoranjan.png" class="img-responsive"/></a>
                </div>
              </div>
              <div class="item hindi">
                <div class="item_content">
                  <a herf="#"  onclick="tv.location.href='player.php?stream=timesnow.html'">
                    <img src="assets/images/timesnow.png" class="img-responsive"/></a>
                </div>
              </div-->

              <!-- ========== Sports Channels =========== -->
              <!--div class="item sports">
                <div class="item_content">
                  <a
                    herf="#"
                    onclick="tv.location.href='player.php?stream=3.html'"
                    ><img
                      src="assets/images/3.png"
                      class="img-responsive"
                  /></a>
                </div>
              </div>
              <div class="item sports">
                <div class="item_content">
                  <a
                    herf="#"
                    onclick="tv.location.href='player.php?stream=4.html'"
                    ><img
                      src="assets/images/foxsports3.png"
                      class="img-responsive"
                  /></a>
                </div>
              </div-->
              <div class="item sports">
                <div class="item_content">
                  <a
                    herf="#"
                    onclick="tv.location.href='player.php?stream=25'"
                    ><img
                      src="assets/images/starsports1.png"
                      class="img-responsive"
                  /></a>
                </div>
              </div>
              <!--div class="item sports">
                <div class="item_content">
                  <a
                    herf="#"
                    onclick="tv.location.href='player.php?stream=starsports2.html'"
                    ><img
                      src="assets/images/starsports2.png"
                      class="img-responsive"
                  /></a>
                </div>
              </div>
              <div class="item sports">
                <div class="item_content">
                  <a
                    herf="#"
                    onclick="tv.location.href='player.php?stream=starsports3.html'"
                    ><img
                      src="assets/images/starsports3.png"
                      class="img-responsive"
                  /></a>
                </div>
              </div>

              <div class="item sports">
                <div class="item_content">
                  <a
                    herf="#"
                    onclick="tv.location.href='player.php?stream=starsports1hd.html'"
                    ><img
                      src="assets/images/starsports1hd.png"
                      class="img-responsive"
                  /></a>
                </div>
              </div>
              <div class="item sports">
                <div class="item_content">
                  <a
                    herf="#"
                    onclick="tv.location.href='player.php?stream=starsports2hd.html'"
                    ><img
                      src="assets/images/starsports2hd.png"
                      class="img-responsive"
                  /></a>
                </div>
              </div-->

              <div class="item sports">
                <div class="item_content">
                  <a
                    herf="#"
                    onclick="tv.location.href='player.php?stream=24'"
                    ><img
                      src="assets/images/sonysixhd.png"
                      class="img-responsive"
                  /></a>
                </div>
              </div>
              <div class="item sports">
                <div class="item_content">
                  <a
                    herf="#"
                    onclick="tv.location.href='player.php?stream=20'"
                    ><img
                      src="assets/images/sony-ten-1.png"
                      class="img-responsive"
                  /></a>
                </div>
              </div>
             <div class="item sports">
                <div class="item_content">
                  <a
                    herf="#"
                    onclick="tv.location.href='player.php?stream=21'"
                    ><img
                      src="assets/images/sony-ten-2.png"
                      class="img-responsive"
                  /></a>
                </div>
              </div>
              <div class="item sports">
                <div class="item_content">
                  <a
                    herf="#"
                    onclick="tv.location.href='player.php?stream=22'"
                    ><img
                      src="assets/images/sony-ten-3.png"
                      class="img-responsive"
                  /></a>
                </div>
              </div>
              <!--div class="item sports">
                <div class="item_content">
                  <a
                    herf="#"
                    onclick="tv.location.href='player.php?stream=tencricket.html'"
                    ><img
                      src="assets/images/tencricket.png"
                      class="img-responsive"
                  /></a>
                </div>
              </div-->
              <div class="item sports">
                <div class="item_content">
                  <a
                    herf="#"
                    onclick="tv.location.href='player.php?stream=23'"
                    ><img
                      src="assets/images/sonyespn.png"
                      class="img-responsive"
                  /></a>
                </div>
              </div>
             <div class="item sports">
                <div class="item_content">
                  <a
                    herf="#"
                    onclick="tv.location.href='player.php?stream=27'"
                    ><img
                      src="assets/images/starsportsselect1hd.png"
                      class="img-responsive"
                  /></a>
                </div>
              </div>
             <div class="item sports">
                <div class="item_content">
                  <a
                    herf="#"
                    onclick="tv.location.href='player.php?stream=28'"
                    ><img
                      src="assets/images/starsportsselect2hd.png"
                      class="img-responsive"
                  /></a>
                </div>
              </div>
              <div class="item sports">
                <div class="item_content">
                  <a
                    herf="#"
                    onclick="tv.location.href='player.php?stream=73'"
                    ><img
                      src="assets/images/ptvsports.png"
                      class="img-responsive"
                  /></a>
                </div>
              </div>

              <!-- ======== Music Channels ========== -->

             <div class="item music">
                <div class="item_content">
                  <a
                    herf="#"
                    onclick="tv.location.href='player.php?stream=58'"
                    ><img
                      src="assets/images/gaanbangla.png"
                      class="img-responsive"
                  /></a>
                </div>
              </div> 
            
            <div class="item music">
                <div class="item_content">
                  <a
                    herf="#"
                    onclick="tv.location.href='player.php?stream=60'"
                    ><img
                      src="assets/images/zoomtv.png"
                      class="img-responsive"
                  /></a>
                </div>
              </div>
            
            <div class="item music">
                <div class="item_content">
                  <a
                    herf="#"
                    onclick="tv.location.href='player.php?stream=48'"
                    ><img
                      src="assets/images/9xm.png"
                      class="img-responsive"
                  /></a>
                </div>
              </div>
              <div class="item music">
                <div class="item_content">
                  <a
                    herf="#"
                    onclick="tv.location.href='player.php?stream=98'"
                    ><img
                      src="assets/images/9x0.png"
                      class="img-responsive"
                  /></a>
                </div>
              </div>
              <div class="item music">
                <div class="item_content">
                  <a
                    herf="#"
                    onclick="tv.location.href='player.php?stream=96'"
                    ><img
                      src="assets/images/sangeetbangla.png"
                      class="img-responsive"
                  /></a>
                </div>
              </div>
              <!--div class="item music">
                <div class="item_content">
                  <a
                    herf="#"
                    onclick="tv.location.href='player.php?stream=vh1.html'"
                    ><img
                      src="assets/images/vh1.png"
                      class="img-responsive"
                  /></a>
                </div>
              </div-->
			  
			  <div class="item music">
                <div class="item_content">
                  <a
                    herf="#"
                    onclick="tv.location.href='player.php?stream=57'"
                    ><img
                      src="assets/images/56.jpg"
                      class="img-responsive"
                  /></a>
                </div>
              </div>
			  
			  <div class="item music">
                <div class="item_content">
                  <a
                    herf="#"
                    onclick="tv.location.href='player.php?stream=46'"
                    ><img
                      src="assets/images/01.jpg"
                      class="img-responsive"
                  /></a>
                </div>
              </div>

              <!-- ======== Documentary Channels ========== -->

              <div class="item documentary">
                <div class="item_content">
                  <a
                    herf="#"
                    onclick="tv.location.href='player.php?stream=43'"
                    ><img
                      src="assets/images/discoveryworld.png"
                      class="img-responsive"
                  /></a>
                </div>
              </div>
              <div class="item documentary">
                <div class="item_content">
                  <a
                    herf="#"
                    onclick="tv.location.href='player.php?stream=35'"
                    ><img
                      src="assets/images/natgeo.png"
                      class="img-responsive"
                  /></a>
                </div>
              </div>
              <!--div class="item documentary">
                <div class="item_content">
                  <a
                    herf="#"
                    onclick="tv.location.href='player.php?stream=natgeowild.html'"
                    ><img
                      src="assets/images/natgeowild.png"
                      class="img-responsive"
                  /></a>
                </div>
              </div>
              <div class="item documentary">
                <div class="item_content">
                  <a
                    herf="#"
                    onclick="tv.location.href='player.php?stream=natgeopeople.html'"
                    ><img
                      src="assets/images/natgeopeople.png"
                      class="img-responsive"
                  /></a>
                </div>
              </div>
              <div class="item documentary">
                <div class="item_content">
                  <a
                    herf="#"
                    onclick="tv.location.href='player.php?stream=animalplanet.html'"
                    ><img
                      src="assets/images/animalplanet.png"
                      class="img-responsive"
                  /></a>
                </div>
              </div>
              <div class="item documentary">
                <div class="item_content">
                  <a
                    herf="#"
                    onclick="tv.location.href='player.php?stream=tlcworld.html'"
                    ><img
                      src="assets/images/tlcworld.png"
                      class="img-responsive"
                  /></a>
                </div>
              </div-->
              <!-- ======== Kids Channels ========== -->
              <div class="item kids">
                <div class="item_content">
                  <a
                    herf="#"
                    onclick="tv.location.href='player.php?stream=10'"
                    ><img
                      src="assets/images/durontotv.png"
                      class="img-responsive"
                  /></a>
                </div>
              </div>
              <!--div class="item kids">
                <div class="item_content">
                  <a
                    herf="#"
                    onclick="tv.location.href='player.php?stream=disneyxd.html'"
                    ><img
                      src="assets/images/disneyxd.png"
                      class="img-responsive"
                  /></a>
                </div>
              </div>
              <div class="item kids">
                <div class="item_content">
                  <a
                    herf="#"
                    onclick="tv.location.href='player.php?stream=disneyjr.html'"
                    ><img
                      src="assets/images/disneyjr.png"
                      class="img-responsive"
                  /></a>
                </div>
              </div>
              <div class="item kids">
                <div class="item_content">
                  <a
                    herf="#"
                    onclick="tv.location.href='player.php?stream=nicksonic.html'"
                    ><img
                      src="assets/images/nicksonic.png"
                      class="img-responsive"
                  /></a>
                </div>
              </div-->
              <div class="item kids">
                <div class="item_content">
                  <a herf="#" onclick="tv.location.href='player.php?stream=55'">
                    <img src="assets/images/nicktv.png" class="img-responsive"/></a>
                </div>
              </div>
              <div class="item kids">
                <div class="item_content">
                  <a herf="#" onclick="tv.location.href='player.php?stream=79'">
                    <img src="assets/images/54.jpg" class="img-responsive"/></a>
                </div>
              </div>
			  

              <!--         End-->
            </div>
          </div>
        </div>
      </div>
    </div>
<div class="container-fluid">
        <div class="row">
          <div class="col-md-12 text-center">

	<marquee style="color:red; font-weight:bolder; font-size: 20px;"></marquee>
</div>
        </div>
      </div>

    <footer class="footer">
      <div class="container-fluid">
        <div class="row">
          <div class="col-md-12 text-center">
            <p>
              Copyright &copy;  2020-2021 &nbsp; iBoxBD. &nbsp; All Rights Reserved. <br/>
			  
            </p>
          </div>
        </div>
      </div>
    </footer>
    <!--Bootstrap min js-->
    <script src="assets/js/bootstrap.min.js"></script>
    <!--Owl filter js-->
    <script src="assets/js/jquery.owl-filter.js"></script>
    <!--Owl carousel min js-->
    <script src="assets/js/owl.carousel.min.js"></script>
    <!--Main js-->
    <script src="assets/js/main.js"></script>
  </body>

</html>
